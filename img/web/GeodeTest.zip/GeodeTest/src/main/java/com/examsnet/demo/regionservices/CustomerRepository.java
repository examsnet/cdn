package com.examsnet.demo.regionservices;

import org.springframework.data.gemfire.repository.query.annotation.Trace;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.stereotype.Repository;

public interface CustomerRepository extends CrudRepository<Customer, Long>{
	
	@Trace
	Customer findByName(String name);
	
	
}
