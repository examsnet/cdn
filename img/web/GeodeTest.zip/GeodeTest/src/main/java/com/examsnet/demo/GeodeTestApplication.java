package com.examsnet.demo;

import org.apache.geode.cache.GemFireCache;
import org.apache.geode.cache.client.ClientCache;
import org.apache.geode.cache.client.ClientRegionShortcut;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.gemfire.config.annotation.ClientCacheApplication;
import org.springframework.data.gemfire.config.annotation.ClientCacheApplication.Locator;
import org.springframework.data.gemfire.config.annotation.EnableEntityDefinedRegions;
import org.springframework.data.gemfire.repository.config.EnableGemfireRepositories;

import com.examsnet.demo.regionservices.Customer;
import com.examsnet.demo.regionservices.CustomerRepository;

import springfox.documentation.swagger2.annotations.EnableSwagger2;
@EnableSwagger2
@SpringBootApplication
@ClientCacheApplication(name="GeodeTestApplication", locators = {
		@Locator(host="locator1", port =10334)
})
 
@EnableGemfireRepositories(basePackageClasses = CustomerRepository.class)
@EnableEntityDefinedRegions(basePackageClasses = Customer.class, clientRegionShortcut = ClientRegionShortcut.PROXY)
public class GeodeTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(GeodeTestApplication.class, args);
	}
	
	 
}
