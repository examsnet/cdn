package com.examsnet.demo.regionservices;

import org.apache.geode.pdx.PdxReader;
import org.apache.geode.pdx.PdxSerializable;
import org.apache.geode.pdx.PdxWriter;
import org.apache.geode.pdx.ReflectionBasedAutoSerializer;
import org.springframework.data.annotation.Id;
import org.springframework.data.gemfire.mapping.annotation.Indexed;
import org.springframework.data.gemfire.mapping.annotation.Region;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;
import lombok.ToString;


@Data
//@NoArgsConstructor
//@AllArgsConstructor
@Region("customers")
@Builder
@ToString
 
public class Customer implements PdxSerializable   {
	private static final long serialVersionUID = 42108163264l;
	 
	private String name;
	

	private int age;
	private Long id;
	public Customer(){}
	public Customer( final Long id) {
	     this.id = id;
	  }
	
	public Customer(String name, int age){
		this.name = name; 
		this.age = age;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	 @Override
	   public String toString() {
	     final StringBuilder buffer =  new StringBuilder( "{ type = ");
	    buffer.append(getClass().getName());
	    buffer.append( ", id = ").append(getId());
	    buffer.append( ", name = ").append(getName());
	    buffer.append( ", age = ").append(getAge());
	    buffer.append( " }");
	    return buffer.toString();
	  }
	 
	 @Override
	   public void fromData(PdxReader pr) {

	    id = pr.readLong( "id");
	    name = pr.readString( "name");
	    age = pr.readInt( "age");
	    
	  }

	  @Override
	   public void toData(PdxWriter pw) {
	    pw.writeLong( "id", id);
	    pw.writeString( "name", name);
	    pw.writeInt( "age", age);
	     
	  }
	 
}
