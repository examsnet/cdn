package com.examsnet.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeodeTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
